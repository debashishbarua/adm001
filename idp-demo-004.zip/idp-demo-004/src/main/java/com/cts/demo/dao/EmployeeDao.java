package com.cts.demo.dao;

import java.util.List;

import com.cts.demo.entity.Employee;
/**
 * 
 */
public interface EmployeeDao {

	/**
	 * Use to add employee to the database
	 * @param employee
	 * @return
	 */
	boolean addEmployee(Employee employee);
	
	List<Employee> findAll();
}
