package com.cts.demo.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.demo.dao.EmployeeDao;
import com.cts.demo.entity.Employee;
import com.cts.demo.util.DBUtil;

public class EmployeeDaoJdbcImpl implements EmployeeDao {

	private static final String SQL_INSERT_EMPLOYEE = "INSERT INTO EMPLOYEE(FIRST_NAME,LAST_NAME) VALUES(?,?)";
	private static final String SQL_FIND_ALL_EMPLOYEE = "SELECT * FROM EMPLOYEE";

	private Connection connection = DBUtil.getConnection();

	@Override
	public boolean addEmployee(Employee employee) {
		PreparedStatement statement = null;
		boolean response = false;
		try {
			statement = connection.prepareStatement(SQL_INSERT_EMPLOYEE);
			statement.setString(1, employee.getFirstName());
			statement.setString(2, employee.getLastName());
			response = statement.executeUpdate() > 0;
		} catch (SQLException e) {
			try {
				statement.close();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
		}
		return response;
	}

	@Override
	public List<Employee> findAll() {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		List<Employee> employees = null;
		try {
			statement = connection.prepareStatement(SQL_FIND_ALL_EMPLOYEE);
			resultSet = statement.executeQuery();
			employees = new ArrayList<>();
			while (resultSet.next()) {
				employees.add(new Employee(
						resultSet.getInt("ID"),
						resultSet.getString("FIRST_NAME"), 
						resultSet.getString("LAST_NAME")));
			}

		} catch (SQLException e) {
			try {
				resultSet.close();
				statement.close();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
		}
		return employees;
	}

}
