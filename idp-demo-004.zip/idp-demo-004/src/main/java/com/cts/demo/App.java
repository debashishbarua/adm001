package com.cts.demo;

import java.util.Scanner;

import com.cts.demo.dao.EmployeeDao;
import com.cts.demo.dao.impl.EmployeeDaoJdbcImpl;
import com.cts.demo.entity.Employee;

/**
 * Hello world!
 *
 */
public class App {

	private static Scanner scanner = new Scanner(System.in);
	private static EmployeeDao dao = new EmployeeDaoJdbcImpl();

	public static void main(String[] args) {
		int choice;
		do {
			System.out.println("1. For Add Employee.");
			System.out.println("2. For Find All Employee.");
			System.out.println("100. Exit.");
			System.out.println("\nEnter Your choice: ");
			choice = Integer.parseInt(scanner.nextLine());
			switch (choice) {
			case 1:
				addEmployee();
				break;
			case 2:
				displayAllEmployee();
				break;
			case 3:
				break;
			case 100:
				System.exit(1);
			default:
				System.err.println("Try Again");
				break;
			}
		} while (true);

	}

	private static void displayAllEmployee() {
		dao.findAll().forEach(e-> System.out.println(e));
		
	}

	private static void addEmployee() {
		dao.addEmployee(new Employee("firstName", "lastName"));
		
	}
}
