package com.cts.demo.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	private static Connection connection = null;

	private static final String USER_NAME = "root";
	private static final String PASSWORD = "mysql";
	private static final String URL = "jdbc:mysql://localhost:3306/adm24jfsa004";

	public static Connection getConnection() {
		try {
			connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
			System.out.println("Connection Success!");
		} catch (SQLException e) {
			System.out.println("Connection Fail: " + e);
		}
		return connection;
	}

	

}
