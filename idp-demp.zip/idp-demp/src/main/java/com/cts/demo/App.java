package com.cts.demo;

import java.util.List;
import java.util.Scanner;

import com.cts.demo.dao.StudentDao;
import com.cts.demo.dao.impl.StudentDaoJdbcImpl;
import com.cts.demo.entity.Student;

/**
 * Hello world!
 *
 */
public class App {
	private static final Scanner SCANNER = new Scanner(System.in);
	private static final StudentDao DAO = new StudentDaoJdbcImpl();

	public static void main(String[] args) {
		int choice;
		
		do {
			System.out.println("1. For add student");
			System.out.println("2. For list student");
			System.out.println("100. For add student");
			System.out.println("Enter your choice:");
			choice = Integer.parseInt(SCANNER.nextLine());
			switch (choice) {
			case 1:
				addStudent();
				break;
			case 2:
				findAllStudent();
				break;
			case 3:
			case 100:
				System.exit(1);
			default:
				System.out.println("Invalid choice! Try again");
				break;
			}

		} while (true);
	}

	private static void findAllStudent() {
		List<Student> findAllStudent = DAO.findAllStudent();
		findAllStudent.forEach(e-> System.out.println(e));

	}

	private static void addStudent() {
		Student s1=new Student(101, "FitstName1", "Lastname1");
		Student s2=new Student(102, "FitstName2", "Lastname2");
		DAO.addStudent(s1);
		DAO.addStudent(s2);
	}
}
