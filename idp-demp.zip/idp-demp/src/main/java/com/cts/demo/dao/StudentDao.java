package com.cts.demo.dao;

import java.util.List;

import com.cts.demo.entity.Student;

public interface StudentDao {
	boolean addStudent(Student student);
	List<Student> findAllStudent();

}
