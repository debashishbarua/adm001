package com.cts.demo.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.demo.dao.StudentDao;
import com.cts.demo.entity.Student;
import com.cts.demo.util.DBUtil;

public class StudentDaoJdbcImpl implements StudentDao {

	private static final String FIND_ALL_STUDENT_SQL = "SELECT * FROM STUDENT";
	private static final String INSERT_STUDENT_SQL = "INSERT INTO STUDENT(ID, FIRST_NAME, LAST_NAME) VALUES(?,?,?)";

	private Connection connection = DBUtil.getConnection();

	@Override
	public boolean addStudent(Student student) {
		PreparedStatement statement = null;
		boolean response=false;
		try {
			statement = connection.prepareStatement(INSERT_STUDENT_SQL);
			statement.setInt(1, student.getId());
			statement.setString(2, student.getFirstName());
			statement.setString(3, student.getLastName());
			response= statement.executeUpdate()>0;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				statement.close();
			} catch (SQLException e) {				
				e.printStackTrace();
			}
		}

		return response;
	}

	@Override
	public List<Student> findAllStudent() {
		List<Student> studentList=null;
		PreparedStatement statement = null;
		ResultSet resultSet=null;
		try {
			statement = connection.prepareStatement(FIND_ALL_STUDENT_SQL);
			resultSet = statement.executeQuery();
			studentList=new ArrayList<>();
			while (resultSet.next()) {
				studentList.add(new Student(
						resultSet.getInt("ID"), 
						resultSet.getString("FIRST_NAME"), 
						resultSet.getString("LAST_NAME")));
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				resultSet.close();
				statement.close();
			} catch (SQLException e) {				
				e.printStackTrace();
			}
		}

		return studentList;
	}

}
